"use strict";
// /***** imports *****/
// import supertest from 'supertest'
// import app from '../index'
// /***** variables *****/
// const request = supertest(app)
// /***** test case *****/
// describe('Test welcome endpoint', () => {
//   it('Get the / endpoint', async () => {
//     const response = await request.get('/')
//     expect(response.status).toBe(200)
//   })
// })
